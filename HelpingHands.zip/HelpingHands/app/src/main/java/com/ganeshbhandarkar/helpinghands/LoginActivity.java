package com.ganeshbhandarkar.helpinghands;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
//
//    private LottieAnimationView lottieAnimationView;
    private TextView createAccountTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        createAccountTextView = findViewById(R.id.create_account_link);

        createAccountTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent createAccountIntent = new Intent(LoginActivity.this,CreateAccountActivity.class);
                createAccountIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(createAccountIntent);
                overridePendingTransition(R.anim.pull_up_from_buttom,R.anim.fade_out);

                finish();
            }
        });

//        lottieAnimationView = findViewById(R.id.LottieAnimationView);
//        startCheckAnimation();
    }

//    private void startCheckAnimation(){
//        ValueAnimator animator=ValueAnimator.ofFloat(0f,1f).setDuration(3000);
//        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
//            @Override
//            public void onAnimationUpdate(ValueAnimator animation) {
//                lottieAnimationView.setProgress((Float)animation.getAnimatedValue());
//            }
//        });
//        if(lottieAnimationView.getProgress()==0f){
//            animator.start();
//        }else {
//            lottieAnimationView.setProgress(0f);
//        }
//    }
}
